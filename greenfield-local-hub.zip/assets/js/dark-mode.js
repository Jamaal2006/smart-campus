// Dark mode toggle script
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}